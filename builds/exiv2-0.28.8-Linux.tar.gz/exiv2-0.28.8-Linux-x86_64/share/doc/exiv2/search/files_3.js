var searchData=
[
  ['iptc_2ehpp_2305',['iptc.hpp',['../iptc_8hpp.html',1,'']]]
];
