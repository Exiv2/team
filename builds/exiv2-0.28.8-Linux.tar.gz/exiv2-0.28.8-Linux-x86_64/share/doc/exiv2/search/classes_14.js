var searchData=
[
  ['uri_2277',['Uri',['../classExiv2_1_1Uri.html',1,'Exiv2']]]
];
