var searchData=
[
  ['iptc_2ehpp_2307',['iptc.hpp',['../iptc_8hpp.html',1,'']]]
];
