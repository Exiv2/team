var searchData=
[
  ['iptc_2ehpp_2304',['iptc.hpp',['../iptc_8hpp.html',1,'']]]
];
